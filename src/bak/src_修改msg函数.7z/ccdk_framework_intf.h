//
/// Copyright (c) 2019 Alibaba-inc.
///
/// All rights reserved.
/// @file    ccdk_framework_intf.h
/// @brief
/// @author  chenyan
/// @version 1.0
/// @date    2019-2-3


#ifndef _CCDK_FRAMEWORK_INTF__H_
#define _CCDK_FRAMEWORK_INTF__H_

#include <rte_eal.h>
#include "rte_cycles.h"

typedef void *(*ccdk_intr_action_t)(void *arg);

typedef void (*ccdk_session_req_action_t)(int argc, void **argv, void *request, int result);

typedef int (*ccdk_server_action_t)(void *arg, void *request);

struct ccdk_session_latency {
    uint32_t session_id;
    uint64_t min_start_2_action_latency;
    uint64_t min_action_latency;
    uint64_t min_action_2_intr_latency;
    uint64_t min_intr_2_complete_latency;
    uint64_t min_start_2_complete_latency;

    uint64_t max_start_2_action_latency;
    uint64_t max_action_latency;
    uint64_t max_action_2_intr_latency;
    uint64_t max_intr_2_complete_latency;
    uint64_t max_start_2_complete_latency;


    uint64_t total_start_2_action_cnt;
    uint64_t total_start_2_action_latency;
    uint64_t avg_start_2_action_latency;

    uint64_t total_action_cnt;
    uint64_t total_action_latency;
    uint64_t avg_action_latency;

    uint64_t total_action_2_intr_cnt;
    uint64_t total_action_2_intr_latency;
    uint64_t avg_action_2_intr_latency;

    uint64_t total_intr_2_complete_cnt;
    uint64_t total_intr_2_complete_latency;
    uint64_t avg_intr_2_complete_latency;

    uint64_t total_start_2_complete_cnt;
    uint64_t total_start_2_complete_latency;
    uint64_t avg_start_2_complete_latency;
};

struct ccdk_framework_init_desc {
    /// @brief 0: binding master's core; >0: no binding or binding the other core id, depend on register server parameters
    uint8_t server_binding_policy;
    uint8_t response_binding_policy;
};

#define CCDK_MSG_MAX_ARGC	10
struct ccdk_framework_msg_desc {
    ccdk_session_req_action_t action;
    int argc;
    void *argv[CCDK_MSG_MAX_ARGC];

    int is_async;
    uint32_t server_id;
    void *msg;
    int timeout;
};

/// @brief intr
int ccdk_framework_intr_action_register(int vector, ccdk_intr_action_t action, void *arg);
int ccdk_framework_intr_init(struct rte_intr_handle *intr_handle);

/// @brief session
int ccdk_framework_open_session(ccdk_session_req_action_t action, int argc, void **argv);
int ccdk_framework_close_session(void);
int ccdk_framework_get_session_latency_info(uint32_t session_id, struct ccdk_session_latency *latency);

/// @brief server
int ccdk_framework_register_server(const char *name, const uint32_t server_id, int thread_num,
                                   ccdk_server_action_t action, void *arg, int core_id);

/// @brief request
int ccdk_framework_set_msg_done(void *msg, int result);
int ccdk_framework_handle_sync_msg(uint32_t server_id, void *msg, int timeout);
int ccdk_framework_handle_async_msg(uint32_t server_id, void *msg);
int ccdk_framework_handle_msg(struct ccdk_framework_msg_desc *msg_desc);

void *ccdk_framework_mempool_get_msg(int size);
int ccdk_framework_mempool_put_msg(void *msg);
void *ccdk_framework_malloc_msg(int size);
void ccdk_framework_free_msg(void *msg);

/// @brief init
int ccdk_framework_init(struct ccdk_framework_init_desc *desc);
void ccdk_framework_cleanup(void);


#endif